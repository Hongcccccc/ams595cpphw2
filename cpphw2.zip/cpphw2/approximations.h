#ifndef APPROXIMATIONS_H
#define APPROXIMATIONS_H

#include <vector>

struct PiResults;

double* approximations(const std::vector<int>& intervals);

#endif // APPROXIMATIONS_H
