//
//  main.cpp
//  cpphw2
//
//  Created by Hongcheng on 11/30/23.
//

#include <iostream>
#include <vector>
#include "pi_approx.h" // Include the header file for Q1
#include "approximations.h" // Include the header file for Q2

int main() {
    // Q1: Print π approximation and error for N = 10000
    PiResults resultQ1 = piApprox(10000);
    std::cout << "Q1 - Approximation of Pi: " << resultQ1.approx << std::endl;
    std::cout << "Q1 - Absolute Error: " << resultQ1.error << std::endl;

    // Q2: Create a vector with elements (101, 102, ..., 107) and print results
    std::vector<int> intervalVector = {101, 102, 103, 104, 105, 106, 107};
    double* resultsQ2 = approximations(intervalVector);

    // Print results
    for (int i = 0; i < intervalVector.size(); ++i) {
        std::cout << "Q2 - Approximation for " << intervalVector[i] << " intervals: " << resultsQ2[i * 2] << std::endl;
        std::cout << "Q2 - Error: " << resultsQ2[i * 2 + 1] << std::endl;
    }

    // Don't forget to free the allocated memory
    delete[] resultsQ2;

    return 0;
}
