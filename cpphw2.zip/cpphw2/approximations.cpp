#include "approximations.h"
#include "pi_approx.h"
#include <vector>

double* approximations(const std::vector<int>& intervals) {
    int size = intervals.size();
    double* resultsArray = new double[size * 2]; // Each approximation and error takes a slot

    for (int i = 0; i < size; ++i) {
        PiResults result = piApprox(intervals[i]);
        resultsArray[i * 2] = result.approx;
        resultsArray[i * 2 + 1] = result.error;
    }

    return resultsArray;
}
