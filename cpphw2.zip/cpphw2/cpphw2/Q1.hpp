//
//  Q1.hpp
//  cpphw2
//
//  Created by Hongcheng on 11/30/23.
//

#ifndef Q1_hpp
#define Q1_hpp

#include <stdio.h>

#endif /* Q1_hpp */
