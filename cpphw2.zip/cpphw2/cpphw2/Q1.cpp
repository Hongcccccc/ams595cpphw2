//
//  Q1.cpp
//  cpphw2
//
//  Created by Hongcheng on 11/30/23.
//

#include "Q1.hpp"
// pi_approx.cpp
#include <iostream>
#include <cmath>

struct PiResults {
    double approx;
    double error;
};

PiResults piApprox(int N) {
    double sum = 0.0;

    for (int k = 0; k < N; ++k) {
        double x_k = (k + 0.5) / N;
        double f_x_k = 4.0 / (1.0 + x_k * x_k);
        sum += f_x_k;
    }

    double approx = sum / N;
    double error = std::abs(approx - M_PI);

    PiResults results;
    results.approx = approx;
    results.error = error;

    return results;
}

int main() {
    // Example: Compute π approximation with 10000 intervals
    int numIntervals = 10000;
    PiResults result = piApprox(numIntervals);

    std::cout << "Approximation of Pi: " << result.approx << std::endl;
    std::cout << "Absolute Error: " << result.error << std::endl;

    return 0;
}
