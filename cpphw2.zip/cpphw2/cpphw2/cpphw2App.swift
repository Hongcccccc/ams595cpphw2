//
//  cpphw2App.swift
//  cpphw2
//
//  Created by Hongcheng on 11/30/23.
//

import SwiftUI

@main
struct cpphw2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
