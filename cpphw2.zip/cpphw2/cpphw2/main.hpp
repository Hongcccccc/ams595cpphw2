//
//  main.hpp
//  cpphw2
//
//  Created by Hongcheng on 11/30/23.
//

#ifndef main_hpp
#define main_hpp

#include <stdio.h>

#endif /* main_hpp */
